#Synsets,Hypernms (cat=>animal),Hyponyms(cat->tiger)
# Synsets are sets of words/ synomyms
#wordnet is dictionery of words
# wordnet folder  is in corpora folder of c:/users/yourname/appdata/roaming/nltk-data    
# if not available , download with  >>> nltk.download('wordnet')

from nltk.corpus import wordnet
word1='weapon'
synarray=wordnet.synsets(word1)
print(synarray)
'''Synset('weapon.n.01'), Synset('weapon.n.02')]    (n means noun)'''
woi=synarray[0]    # woi means word of interest
print(woi.definition())
print(woi.name())
print(woi.pos())    # v means verb, n means noun, a  means adjective, r means adverb
#----------------------------------------------------------------------

#lemmas, synomyms , Antonyms
#Lemma is like stem eg, running, ran, run....
# break,breaking, breakthrough   stem words called lemmas

#-----------------------------------------------------------------
#Bigrams and Trigrams  (set of 2 word / set of 3 words)
#which two words are quite common in use in bigrams
# useful for training data
'''
from nltk.corpus import webtext
from nltk.collocations import BigramCollocationFinder
from nltk.metrics import BigramAssocMeasures

textWords= [w.lower() for w  in webtext.words ('pirates.txt')]
finder= BigramCollocationFinder.from_words(textWords)
finder.nbest(BigramAssocMeasures._expected_values,10)
'''
