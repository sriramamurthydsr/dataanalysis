'''
# Stemming

# A word stem is part of a word. It is sort of a normalization idea, 
# but linguistic.   So  stemming is cutting part of word.
#For example, the stem of the word waiting is wait, waits, waited
# The reason to do this is to save data and also indexing on cook 
# rather than creating index on cooking,cooked... eg. Google search
'''

from nltk.stem  import PorterStemmer,LancasterStemmer,RegexpStemmer
# PorterStemmer is least aggressive

pstemmer=PorterStemmer()
print(pstemmer.stem('waited'))    #wait      dancing -> danc , cooking->cook
print(pstemmer.stem('cookery'))   #cookeri

#LancasterStemmer works on huge data, quite faster than PorterStemmer
lstemmer=LancasterStemmer()   # quite aggressive
print(lstemmer.stem('cookery'))    #cookery


#RegedStemmer
rstemmer=RegexpStemmer('ing')
print(rstemmer.stem('skiing'))     # ski           dancing->danc  king=>k
print(lstemmer.stem('king'))    #king 

rstem=RegexpStemmer('er')
print(rstemmer.stem('writer'))  # writ

#SnowballStemmer , AggressiveStemmer..
