'''
Tokenization
Tokenization is the first step in text analytics. 
The process of breaking down a text paragraph into 
smaller chunks such as words or sentence is called 
Tokenization. Token is a single 
entity that is building blocks for sentence or paragraph.
'''

from nltk.tokenize import sent_tokenize
data = "All work and no play makes murthy dull boy. All work and no play makes jack a dull boy."
tokenized_text=sent_tokenize(data)
print(tokenized_text)
tokenized_text[0]   #first element in array.

#another way with nltk.data
import nltk.data
toknizr=nltk.data.load('tokenizers/punkt/english.pickle')
parag="I like python. I fly high.  I love TV. You are great."
result=toknizr.tokenize(parag)
print(result)
print(result[2])
#------------------------------------------------------
from nltk.tokenize import word_tokenize
#word tokenizer
array_words=word_tokenize('This is murthy teaching you nltk')
print(array_words)

#Treebank tokenizer
from nltk.tokenize import word_tokenize
from nltk.tokenize import TreebankWordTokenizer
from nltk.tokenize import WordPunctTokenizer

tok1= TreebankWordTokenizer()
tok2= WordPunctTokenizer()
sent1='Hi my name is Murthy'
print(word_tokenize(sent1))  # word tokineizer
tok1.tokenize(sent1) 
tok2.tokenize(sent1)
# word-tokenize is method  but Treenabk andWordPunct are classes.

#The diferrence 
sent2="I won't allow you to leave this place"
print(word_tokenize(sent2)) # observe the output (So not proper way)
print(tok1.tokenize(sent2)) # observe the output (Same as above)
print(tok2.tokenize(sent2)) # observe the output (better)


from nltk.corpus import stopwords
nltk.download('stopwords')
data = "All work and no play makes Murthy a dull boy. All work and no play makes jack a dull boy."
stopWords = set(stopwords.words('english'))
ensw= stopwords.words('english')   #try this and observe stop words
print(ensw)


words = word_tokenize(data)
filterArray=[item for item in words if item not in ensw]
print('Stop words :',filterArray)


wordsFiltered = []
for w in words:
    if w not in stopWords:
        wordsFiltered.append(w)
 
print(wordsFiltered)

#------------------------------------------------------------

# Using regular expressions with nltk
from nltk.tokenize import regexp_tokenize
sent3="I can't do this and i don't want to learn nltk"
res=regexp_tokenize(sent3,"[\w']+")
print(res)
#-----------------------------------------------------------