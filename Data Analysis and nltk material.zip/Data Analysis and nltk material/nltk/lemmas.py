from nltk.corpus import wordnet
synsetArray=wordnet.synsets('win')
print(synsetArray)  #observe the output.
woi=synsetArray[2]     # win.v.01   verb
print(woi.definition())
print(woi.lemmas())  # generates lemmas array

synArr=[]
antArr=[]
for syn in synsetArray:
    for lem  in syn.lemmas():
        synArr.append(lem.name())
        print(set(synArr))  # set is to remove duplicate win
        print(len(set(synArr)))

#Antonyms (oppsite word)
ant=woi.lemmas()[0].antonyms()[0].name()
print(ant)# lose

#Lammatization
# There is difference between stemming and lammatization
from nltk.stem import WordNetLemmatizer
lzr=WordNetLemmatizer()
print(lzr.lemmatize('dancing'))  # as it is noun , it retain lemma - dancing
print(lzr.lemmatize('working'))  # noun/adjective  , --> working

#with pos (Part of Speach) as second argument
print(lzr.lemmatize('dancing',pos='v'))  # dance    v=verb
print(lzr.lemmatize('working',pos='a'))  # working    a= adjective
print(lzr.lemmatize('buses'))    #bus
print(lzr.lemmatize('believes'))    #belief

from nltk.stem import PorterStemmer
stm=PorterStemmer()
print(stm.stem('dancing')) #danc
print(stm.stem('believes'))    #belief
#------------------------------------------------------

